package com.chathead;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ChatHeadClient implements ClientModInitializer {
    public static final ChatHeadConfig CONFIG = ChatHeadConfig.load();
    private static final CrossbowController CROSSBOW = new CrossbowController();

    // Not passed to KeyBindingHelper: hidden from Controls and never written to options.txt.
    private static final KeyBinding TRIGGER = new KeyBinding(
            "key.chat_head.crossbow", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, "key.categories.chat_head");

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> CROSSBOW.tick(client, TRIGGER.wasPressed()));
    }
}
